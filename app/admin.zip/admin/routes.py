from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.InformacionEmpresa.routes import allowed_file
from app.models import Categoria, TipoCategoria, Usuario, Negocio, TipoUsuario, Rubro
from werkzeug.utils import secure_filename
import os

UPLOAD_FOLDER = 'app/static/uploads/dni'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Crea la carpeta si no existe


admin_bp = Blueprint('admin', __name__, template_folder='templates')

# Dashboard del administrador
@admin_bp.route('/')
@login_required
def dashboard():
    if current_user.id_tipo_usuario != 1:  # Suponiendo que 1 es el ID para administradores
        flash('Acceso denegado. No tienes permisos para ver este panel.', 'danger')
        return redirect(url_for('main.index'))
    return render_template('admin/admin_dashboard.html', user=current_user)

# Registro de Usuario
@admin_bp.route('/registrar_usuario', methods=['GET', 'POST'])
@login_required
def registrar_usuario():
    if current_user.id_tipo_usuario != 1:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('admin.dashboard'))

    if request.method == 'POST':
        nombre = request.form['nombre']
        dni = request.form.get('dni', '')
        correo = request.form['correo']
        celular = request.form['celular']
        contrasena = request.form['contrasena']
        username = ''.join(nombre.split()).lower()
        id_tipo_usuario = request.form.get('id_tipo_usuario')
        if not id_tipo_usuario:
            flash('Debes seleccionar un tipo de usuario.', 'danger')
            return redirect(url_for('admin.registrar_usuario'))

        try:
            id_tipo_usuario = int(id_tipo_usuario)
        except ValueError:
            flash('Tipo de usuario inválido.', 'danger')
            return redirect(url_for('admin.registrar_usuario'))

        if id_tipo_usuario not in [1, 2]:
            flash('Tipo de usuario no válido.', 'danger')
            return redirect(url_for('admin.registrar_usuario'))


        

          # Cambios aquí ⬇
        foto_dni_frontal = request.files.get('foto_dni_frontal')
        foto_dni_posterior = request.files.get('foto_dni_posterior')

        frontal_filename = posterior_filename = None
        if foto_dni_frontal and allowed_file(foto_dni_frontal.filename):
            frontal_filename = secure_filename(foto_dni_frontal.filename)
            foto_dni_frontal.save(os.path.join(UPLOAD_FOLDER, frontal_filename))

        if foto_dni_posterior and allowed_file(foto_dni_posterior.filename):
            posterior_filename = secure_filename(foto_dni_posterior.filename)
            foto_dni_posterior.save(os.path.join(UPLOAD_FOLDER, posterior_filename))

        nuevo_usuario = Usuario(
            nombre=nombre,
            dni=dni,
            email=correo,
            celular=celular,
            username=username,
            password=contrasena,
            id_tipo_usuario=id_tipo_usuario,
            foto_dni_frontal=frontal_filename,       # Cambio aquí ⬅
            foto_dni_posterior=posterior_filename    # Cambio aquí ⬅
        )
        db.session.add(nuevo_usuario)
        db.session.commit()

        flash('Usuario registrado con éxito.', 'success')
        return redirect(url_for('admin.dashboard'))

    tipos = TipoUsuario.query.all()
    return render_template('admin/registro_usuario.html', tipos=tipos)

# Registro de Negocio
@admin_bp.route('/registrar_negocio', methods=['GET', 'POST'])
@login_required
def registrar_negocio():
    if current_user.id_tipo_usuario != 1:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('admin.dashboard'))

    if request.method == 'POST':
        nombre_negocio = request.form.get('nombre_negocio', '').strip()
        ruc = request.form.get('ruc', '').strip()
        razon_social = request.form.get('razon_social', '').strip()
        direccion = request.form.get('direccion', '').strip()
        departamento = request.form.get('departamento', '').strip()
        provincia = request.form.get('provincia', '').strip()
        distrito = request.form.get('distrito', '').strip()
        rubro_id = request.form.get('rubro_id')

        # 🔑 Verificación del dueño del negocio
        usuario_id = request.form.get('usuario_id')
        
        if not usuario_id or not usuario_id.isdigit():
            flash('Debes seleccionar un dueño de negocio válido.', 'danger')
            return redirect(url_for('admin.registrar_negocio'))
        
        usuario = Usuario.query.get(int(usuario_id))
        if not usuario:
            flash('El usuario seleccionado no existe.', 'danger')
            return redirect(url_for('admin.registrar_negocio'))
        
        if usuario.id_tipo_usuario != 2:
            flash('El usuario seleccionado no es un dueño de tienda.', 'danger')
            return redirect(url_for('admin.registrar_negocio'))

        telefono = usuario.celular if usuario.celular else ''

        # 💾 Registro del negocio con manejo de errores
        try:
            nuevo_negocio = Negocio(
                nombre=nombre_negocio,
                ruc=ruc,
                razon_social=razon_social,
                direccion=direccion,
                telefono=telefono,
                departamento=departamento,
                provincia=provincia,
                distrito=distrito,
                rubro_id=rubro_id,
                usuario_id=usuario.id
            )
            db.session.add(nuevo_negocio)
            db.session.commit()
            flash('Negocio registrado con éxito.', 'success')
            return redirect(url_for('admin.dashboard'))
        
        except Exception as e:
            db.session.rollback()
            flash(f'Ocurrió un error al registrar el negocio: {str(e)}', 'danger')
            return redirect(url_for('admin.registrar_negocio'))

    rubros = Rubro.query.all()
    usuarios = Usuario.query.filter_by(id_tipo_usuario=2).all()
    return render_template('admin/registro_negocio.html', rubros=rubros, usuarios=usuarios)

# Consultar Usuario
@admin_bp.route('/consultar_usuarios/<int:user_id>')
@login_required
def consultar_usuario(user_id):
    if current_user.id_tipo_usuario != 1:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('admin.dashboard'))

    usuarios = Usuario.query.all()  # Obtener todos los usuarios
    return render_template('admin/consultar_usuarios.html', usuarios=usuarios)

# Consultar Negocio
@admin_bp.route('/consultar_negocios')
@login_required
def consultar_negocios():
    if current_user.id_tipo_usuario != 1:
        flash('Acceso denegado.', 'danger')
        return redirect(url_for('admin.dashboard'))

    negocios = Negocio.query.all()
    return render_template('admin/consultar_negocios.html', negocios=negocios)


